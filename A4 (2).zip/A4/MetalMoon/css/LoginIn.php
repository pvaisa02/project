<html>
<head>
<script src="Javascript.js"></script>
</head>
<body>
<div class="wrapper">
<h1><div class="LogoContainer">
<img class="Logo" src="images/Logo.png" alt="Logo.png"></div>Metal Moon</h1>
<div class="iconbox">
<img class="icons" src="images/signinup.png" alt="Register"><!--https://www.iconfinder.com/icons/1200283/astronaut_cosmonaut_helmet_ios_man_space_spaceman_icon-->
<img class="icons" src="images/shoppingcart.png" alt="Shopping Cart"><!--https://www.flaticon.com/free-icon/ursa-major_167324#term=big%20dipper&page=1&position=7-->
<img class="social" src="images/facebook.png" alt="Facebook"><!--https://www.flaticon.com/free-icon/facebook_1051309-->
<img class="social" src="images/instagram.png" alt="Instagram"><!--https://www.flaticon.com/free-icon/instagram_1051313-->
<img class="social" src="images/twitter.png" alt="Twitter"></div><!--https://www.flaticon.com/free-icon/twitter_1051331-->


</body>
</div>
</html>